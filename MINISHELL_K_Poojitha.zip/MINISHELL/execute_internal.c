/*
NAME                    : K.Poojitha
DATE                    : 06-04-2026
DESCRIPTION             : Implement a minimalistic shell, mini-shell(msh) as part of the Linux Internal module.*/
#include "minishell.h"
char buf[200];
void execute_internal_commands(char *input_string){
    
    static int status;
    if(strncmp(input_string,"cd",2) == 0)
    {
        int ret = chdir(input_string + 3);  //Change directory
        if(ret != 0)
            perror("cd");
    }

    if(strcmp(input_string,"pwd")==0){
        char buf1[200];
        if(getcwd(buf1,sizeof(buf1)) != NULL) //Get current path
            printf("%s\n",buf1);
        else
        {
            perror("getcwd");
            return;
        }
    }

    if(strcmp(input_string,"clear")==0)
        system("clear");

    if(strcmp(input_string,"exit")==0)
        exit(0);            //Exit shell

    if(strcmp(input_string,"echo $$")==0)
        printf("%d\n",getpid());    //Print Shell pid
     
    if(strcmp(input_string,"echo $?")==0){
        if (WIFEXITED(status))      //Here write the untraced 
            printf("exit code -> %d\n",WEXITSTATUS(status));
    }

    if(strcmp(input_string,"echo $SHELL")==0){
        printf("%s\n", buf);      
    } 
}