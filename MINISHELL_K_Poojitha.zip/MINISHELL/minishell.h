#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdio_ext.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
 

#define BUILTIN		1       //for builting command
#define EXTERNAL	2       //for external command
#define NO_COMMAND  3       //command not found

#define SUCCESS     0
#define FAILURE     -1

#define RED             "\033[31m"
#define BOLD_GREEN      "\033[1;32m"
#define YELLOW          "\033[33m"
#define BLUE            "\033[34m"
#define MAGENTA         "\033[35m"
#define CYAN            "\033[36m"
#define RESET           "\033[0m"
/*structure for jobs list (fg/bg/jobs)*/
typedef struct fbj{
    int job_id;                     //job number
    pid_t pid;                      //process id
    char input_string[100];         //command stored
    int flag;                       //0->stopped,1->running
    struct fbj*link;                //next node
    
}Slist;
extern Slist *head;
extern int child_pid;
extern char input_string[];
extern int job_id;

void scan_input(char *prompt, char *input_string);
char *get_command(char *input_string);
int check_command_type(char *command);
void execute_internal_commands(char *input_string);
void execute_external_commands(char *input_string);
void signal_handler(int sig_num);
void extract_external_commands(char **external_commands);
void fg();
void bg();
void jobs(Slist *head);

int insert_at_last(Slist **head, int job_id, pid_t pid, char *cmd, int flag);
int delete_last(Slist **head);
#endif