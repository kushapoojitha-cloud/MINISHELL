/*
NAME                    : K.Poojitha
DATE                    : 06-04-2026
DESCRIPTION             : Implement a minimalistic shell, mini-shell(msh) as part of the Linux Internal module.*/
#include "minishell.h"
char type;                             //stores command type
char *command;                         //Pointer to store extracted command name

void scan_input(char *prompt, char *input_string)
{
    /*Infinite loop to keep shell running*/
    while (1)
    {
        printf(BOLD_GREEN);
        printf("%s ", prompt);     //Print shell promt              
        fflush(stdout);            //Force printing immediatly
        printf(RESET);
        input_string[0]='\0';       //Clear previous input
        if(scanf("%[^\n]", input_string) == EOF)        //Read entire line untile newline
        {
            printf("\n");
            exit(0);
        }    
        getchar();                                  //Remove newline from input buffer
        if ( input_string[0] == '\0')       //if user pressed only ENTER
            continue;                       //Restart loop
        command = get_command(input_string);//Extract first word(command)
        type = check_command_type(command);            //Determine command type
        /*Checking if user s changing prompt*/
        if(strncmp(input_string, "PS1", 3) == 0)
        {
            if (strchr(input_string, ' ') != NULL) //Prompt should not contain spaces
                printf("Command no found\n");
            else{
                char *new_prompt = input_string + 4;    //skip "PS1="
                strcpy(prompt, new_prompt);             //Update prompt
            }
            continue;
        } 
        /*Foreground command*/
        else if (strcmp(command,"fg") == 0)
        {
            fg();
            continue;
        }
        /*Background command*/
        else if ( strcmp(command,"bg") == 0)
        {
            bg();
            continue;
        }
        /*Display jobs*/
        else if ( strcmp(command ,"jobs") == 0)
        {
            jobs(head);
            continue;
        }  
        
        if(type == BUILTIN)                            //Internal command
        {
            execute_internal_commands(input_string);
        }
        else if(type == EXTERNAL)                       //External command
        {
            child_pid=fork();                           //Create child process
            if(child_pid>0){                            //parent process
                int status;
                waitpid(child_pid, &status, WUNTRACED); //Wait for child
                child_pid = 0;
            }
            else if(child_pid==0)                       //Child process
            {
                signal(SIGINT, SIG_DFL);             //allow ctrl+c in child
                signal(SIGTSTP, SIG_DFL);            //allow ctrl+z in child
                execute_external_commands(input_string);    //Execute command
                exit(0);
            }
        }
        else                                    //Command not found
        {
            printf("Command not found\n");
        }
    }
}

void fg()
{
    extern Slist *head;     //job list head
    int status;
    if(head == NULL)    //If no background jobs
    {
        printf("No jobs\n");
        return;
    }
    Slist *temp = head;
    while(temp->link)           //Move to last job
        temp = temp-> link;
    printf("%s\n",temp->input_string);  //Print command
    fflush(stdout);
    kill(temp->pid, SIGCONT);           //Resume stopped process
    waitpid(temp->pid, &status, WUNTRACED); //Wait for it
     job_id--;
    delete_last(&head);         //Remove job from list
}

void bg()
{
    extern Slist *head;
    if(head == NULL)        //No background jobs
    {
        printf("No jobs\n");
        return;
    }
    Slist *temp = head;
    while(temp->link)       //Go to last job
        temp = temp-> link;
    kill(temp->pid, SIGCONT);       //Resume job
    temp->flag = 1;                  //Mark as running
    printf("[%d] %d Running in background\n",temp->job_id,temp->pid);
}

void jobs(Slist *head)
{
	if (head == NULL)       //If no jobs
	{
		printf("No jobs\n");
        return;
	}
    else
    {
	    while (head)	//Traverse linked list	
	    {
		    if(head->flag == 0)
                printf("\n[%d]+  Stopped                 %d     %s\n",head->job_id,head->pid,head->input_string);
            else
                printf("\n[%d]+  Running                 %d     %s\n",head->job_id,head->pid,head->input_string);
		    head = head -> link;        //Move to next node
	    }
    }
}

int insert_at_last(Slist **head, int job_id, pid_t pid, char *cmd, int flag)
{
    Slist *new_node=malloc(sizeof(Slist));  //Allocate memory for node
    if(new_node==NULL)
        return FAILURE;
    new_node->job_id=job_id;        //Store job id
    new_node->pid=pid;              //Store process id
    strcpy(new_node->input_string, cmd);    //Store command
    new_node->flag = flag;      //Running/stopped
    new_node->link = NULL;      //Last node
    if(*head==NULL){            //If list empty    
        *head=new_node;
        return SUCCESS;
    }
    else
    {
        Slist *temp=*head;
        while(temp->link!=NULL)     //Traverse list
        {
            temp = temp->link;
        }
        temp->link=new_node;        //Attach node
    }
    return SUCCESS;
} 

int delete_last(Slist **head)
{
    if(*head == NULL)
        return FAILURE;
    if((*head)->link==NULL)     //If only one node
    {
        free(*head);
        *head=NULL;
        return SUCCESS;
    }
    else
    {
        Slist *temp=*head;
        while(temp->link->link!=NULL)       //Move to second last node
            temp = temp->link;
        free(temp->link);       //Free last node
        temp->link=NULL;
    }
    return SUCCESS;
}