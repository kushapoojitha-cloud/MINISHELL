/*
NAME                    : K.Poojitha
DATE                    : 06-04-2026
DESCRIPTION             : Implement a minimalistic shell, mini-shell(msh) as part of the Linux Internal module.*/
#include "minishell.h"
char *get_command(char *input_string){
    static char command[50];
    int i = 0;
    while(input_string[i] != ' ' && input_string[i] != '\0') 
    {
        command[i]=input_string[i];         //Copy character
        i++;
    }
    command[i]='\0';            //Terminate string
    return command;             //Return command
}