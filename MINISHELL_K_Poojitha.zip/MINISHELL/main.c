/*
NAME                    : K.Poojitha
DATE                    : 06-04-2026
DESCRIPTION             : Implement a minimalistic shell, mini-shell(msh) as part of the Linux Internal module.*/
#include "minishell.h"
char *external_commands[250];           
char prompt[20] = "Minishell:$";
char input_string[100];
Slist *head = NULL;
int child_pid = 0, job_id = 0;
extern char buf[200];
void signal_handler(int sig_num)
{
    if(sig_num == SIGINT)   //Ctrl + C
    {
        printf(BOLD_GREEN"\n%s "RESET, prompt);
        fflush(stdout);
    }
    else if(sig_num == SIGTSTP)   // Ctrl + Z
    {
        if(child_pid > 0){
            /*store stopped process in jobs list*/
            job_id++;
            insert_at_last(&head, job_id, child_pid,input_string,0);
            printf("\n[%d]+  Stopped                 %d     %s\n",job_id,child_pid,input_string);
            
        } 
        else
        {
        printf(BOLD_GREEN"\n%s "RESET, prompt);
        fflush(stdout);
        }
    }
    else if(sig_num == SIGCHLD)   // child terminated
    {
        pid_t pid;
        int status;
        while((pid = waitpid(-1, &status, WNOHANG)) > 0)
        {
            if(WIFEXITED(status) || WIFSIGNALED(status)){
                job_id--;
                delete_last(&head);                          //remove last stopped process
            }
        }
    }
}

int main(){
    system("clear");                    //clear terminal
     if(getcwd(buf,sizeof(buf)) == NULL) //Get current path
     {
        printf("Failed\n");
     }
    signal(SIGINT, signal_handler);     //handle Ctrl+c
    signal(SIGTSTP, signal_handler);    //handle Ctrl+z
    signal(SIGCHLD, signal_handler);    //handle child termination
    extract_external_commands(external_commands);//read commands from .txt file
    scan_input(prompt, input_string);       //start shell loop

    return 0;
}